﻿using ParallelWaitAll;

internal class Program
{

    public static long AdvancedSumCalculation(int begin, int step, int threadPoolSize)
    {
        long expectedSum = 0;
        Thread[] threadsPool = new Thread[threadPoolSize];
        for (int i = 0; i < threadsPool.Length; i++)
        {
            // n - begin
            // m = end
            //((m - n + 1) * (n + m)) / 2;
            expectedSum += ((step) * (2 * begin + step - 1)) / 2;
            begin += step;
        }
        return expectedSum;
    }

    private static void Main(string[] args)
    {
        int begin = 1;
        int step = 100;
        int threadPoolSize = 4;
        long actualSum = 0;
        long expectedSum = AdvancedSumCalculation(begin, step, threadPoolSize);
        for (int i = 0; i < threadPoolSize; i++)
        {
            for (global::System.Int32 j = begin; j < begin + step; j++)
            {
                actualSum += j;
            }
            begin += step;
        }
        Console.WriteLine(expectedSum);
        Console.WriteLine(actualSum);
    }
}