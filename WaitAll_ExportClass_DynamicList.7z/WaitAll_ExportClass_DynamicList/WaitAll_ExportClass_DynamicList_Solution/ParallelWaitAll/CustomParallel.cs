﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ParallelWaitAll.TaskQueue;

namespace ParallelWaitAll
{
    public static class CustomParallel
    {
        public static long WaitAll(TaskDelegate[] tasks)
        {
            return WaitAll(tasks, Environment.ProcessorCount);
        }

        public static long WaitAll(TaskDelegate[] tasks, int poolSize)
        {
            Stopwatch sw = Stopwatch.StartNew();
            TaskQueue taskQueue = new TaskQueue(poolSize);
            foreach (var item in tasks)
            {
                taskQueue.EnqueueTask(item);
            }
            taskQueue.WaitTasksCompletion();
            sw.Stop();

            return sw.ElapsedMilliseconds;
        }
    }
}
