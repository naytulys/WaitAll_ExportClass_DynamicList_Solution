﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParallelWaitAll
{
    public class LockingQueue<T> : Queue<T?> where T : System.Delegate?
    {
        private static object synchronizationObject = new object();

        public bool IsEmpty()
        {
            return this.Count == 0;
        }

        public LockingQueue() : base() { }

        public new void Enqueue(T? item)
        {
            lock (synchronizationObject)
            {
                base.Enqueue(item);
                Monitor.Pulse(synchronizationObject);
            }
        }
        public new T? Dequeue()
        {
            lock (synchronizationObject)
            {
                while (this.IsEmpty())
                {
                    Monitor.Wait(synchronizationObject);
                }
                return base.Dequeue();
            }

        }
    }
}
