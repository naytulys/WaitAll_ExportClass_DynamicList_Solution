﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParallelWaitAll
{
    public class TaskQueue
    {
        public delegate void TaskDelegate();

        private Thread[] threadsPool;
        private LockingQueue<TaskDelegate> tasksFromLockingQueue;

        public TaskQueue(int count)
        {
            if (count < 1)
            {
                throw new ArgumentException("Thread pool size must be graner than zero");
            }
            threadsPool = new Thread[count];
            tasksFromLockingQueue = new LockingQueue<TaskDelegate>();

            for (int i = 0; i < threadsPool.Length; i++)
            {
                var thread = new Thread(EntryThreadsTask);
                thread.Name = "Thread" + i;
                thread.IsBackground = true;
                //threadsPool.Add(thread);
                threadsPool[i] = thread;
                thread.Start();
            }
        }

        
        public void EnqueueTask(TaskDelegate? task)
        {
            tasksFromLockingQueue.Enqueue(task);
        }

        public void WaitTasksCompletion()
        {
            for (int i = 0; i < threadsPool.Length; i++)
            {
                this.EnqueueTask(null);
            }
            foreach (var thread in threadsPool)
            {
                thread.Join();
            }
        }

        private void EntryThreadsTask()
        {
            while (true)
            {
                TaskDelegate? taskDelegate = tasksFromLockingQueue.Dequeue();
                if (taskDelegate == null)
                {
                    break;
                }
                try
                {
                    taskDelegate();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
        }

    }
}
