﻿using ExportClassAttribute;
using System.Reflection;

internal class Program
{
    private static void Main(string[] args)
    {
        string dllPath = "D:\\Documents\\3-COURCE-2Sem\\СПП\\AAA-Solutions\\WaitAll_ExportClass_DynamicList\\WaitAll_ExportClass_DynamicList_Solution\\ClassLibraryExample\\bin\\Debug\\net8.0\\ClassLibraryExample.dll";
        var assembly = Assembly.LoadFile(dllPath);
        Type[] assemblyTypes = assembly.GetTypes();
        foreach (Type type in assemblyTypes) 
        {
            if (Attribute.IsDefined(type, typeof(ExportClass)))
            {
                object[] attributes = type.GetCustomAttributes(true);
                bool isExportClassContains = false;
                foreach (object attribute in attributes) 
                {
                    if (attribute.GetType().Equals(typeof(ExportClass)))
                    {
                        isExportClassContains = true;
                        break;
                    }
                }
                if (isExportClassContains) 
                {
                    Console.WriteLine("Class: " + type.Name);
                    foreach (var field in type.GetFields(BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance))
                    {
                        Console.WriteLine("\tField: " +  field.Name + field.FieldType.Name);
                    }


                    foreach (var property in type.GetProperties(BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance))
                    {
                        Console.WriteLine("\tProperty: " + property.Name + property.PropertyType.Name);
                    }

                }
            }
        }

    }
}