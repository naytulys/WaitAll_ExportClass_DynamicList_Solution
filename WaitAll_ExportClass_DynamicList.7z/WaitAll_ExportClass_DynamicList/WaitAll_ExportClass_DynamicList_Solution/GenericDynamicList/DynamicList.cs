﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericDynamicList
{
	public class DynamicList<T> : IEnumerable<T> where T : notnull
    {
		private const int DEFAULT_INITIAL_SIZE = 10;
		private T[] _array;
		private int _actualSize = 0;

		public int Count
		{
			get
			{
				return _actualSize;
			}
		}

		public T[] Items
		{
			get
			{
				T[] result = new T[_actualSize];
				Array.Copy(_array, 0, result, 0, _actualSize);
				return result;
			}
		}

		
		public DynamicList(int initialSize)
		{

			if (initialSize > 0)
			{
				_array = new T[initialSize];
			}
			else
			{
				throw new ArgumentException("Initial size less than zero");
			}
		}

		public DynamicList()
		{
			_array = new T[DEFAULT_INITIAL_SIZE];

		}

		public DynamicList(T[] initialArray)
		{
            _array = new T[initialArray.Length];
			Array.Copy(initialArray, 0, _array, 0, initialArray.Length);
			_actualSize = initialArray.Length;
        }


		public void Add(T value)
		{
			if (_actualSize >= _array.Length)
			{
				var newSize = _array.Length * 2;
				var newArray = new T[newSize];
				_array.CopyTo(newArray, 0);
				_array = newArray;
			}

			_array[_actualSize] = value;
			_actualSize++;
		}

		public void RemoveAt(int index)
		{
			if (index >= _actualSize || index < 0)
			{
				throw new IndexOutOfRangeException();
			}
			for (int i = index + 1; i < _actualSize; i++)
			{
				_array[i - 1] = _array[i];
			}
			_actualSize--;
		}

		public int IndexOf(T item)
		{
			for (int i = 0; i < _actualSize; i++)
			{
                if (item.Equals(_array[i]))
                {
					return i;
                }
            }
			return -1;
		}

		public void Remove(T value)
		{
            int index = IndexOf(value);
			if (index > 0)
			{
				RemoveAt(index);
				
			}
		}

		public void Clear()
		{
			_actualSize = 0;
		}

		public IEnumerator<T> GetEnumerator()
		{
            for (int i = 0; i < _actualSize; i++)
            {
                yield return _array[i];
            }
        }

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}
	}
}
