using ParallelWaitAll;
using System.Diagnostics.Metrics;
using static ParallelWaitAll.TaskQueue;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ParallelWaitAllTests
{
    public class WaitAllTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void PresentSimpleTest()
        {
            var counter = 0;
            TaskQueue.TaskDelegate[] tasks = new TaskQueue.TaskDelegate[]
            {
                delegate ()
                {
                    Interlocked.Increment(ref counter);
                },
                delegate ()
                {
                    Thread.Sleep(300);
                    Interlocked.Increment(ref counter);
                },
                delegate ()
                {
                    Thread.Sleep(300);
                    Interlocked.Increment(ref counter);
                    Thread.Sleep(100);
                }
            };
            long executionTime = CustomParallel.WaitAll(tasks);
            Assert.That(counter, Is.EqualTo(3));
        }
        [Test]
        public void ExtendedTest()
        {
            const int expected = 100;
            var counter = 0;

            TaskQueue.TaskDelegate[] tasks = new TaskQueue.TaskDelegate[expected];

            for (int i = 0; i < expected; i++)
            {
                tasks[i] = delegate ()
                {
                    Interlocked.Increment(ref counter);
                };
            }

            long executionTime = CustomParallel.WaitAll(tasks);

            Assert.That(counter, Is.EqualTo(expected));
        }


        [Test]
        [TestCase(1, 100, 4)]
        [TestCase(255, 773, 3)]
        [TestCase(356, 989, 5)]
        public void MyltiThreadingTest(int begin, int step, int threadPoolSize)
        {
            int beginCopy = begin;
            long actualSum = 0;
            long expectedSum = 0;
            Thread[] threadsPool = new Thread[threadPoolSize];
            for (int i = 0; i < threadsPool.Length; i++)
            {
                // n - begin
                // m = end
                //((m - n + 1) * (n + m)) / 2;
                expectedSum += ((step) * ( 2 * begin + step - 1)) / 2;
                begin += step;
            }
            begin = beginCopy;
            for (int i = 0; i < threadsPool.Length; i++)
            {
                int beginBound = begin;
                TaskQueue.TaskDelegate[] tasks = new TaskQueue.TaskDelegate[step];
                var thread = new Thread(delegate ()
                {
                    for (int j = 0; j < step; j++)
                    {
                        int copyJ = j;
                        tasks[j] = delegate ()
                        {
                            Interlocked.Add(ref actualSum, beginBound + copyJ);
                        };
                    }
                    long executionTime = CustomParallel.WaitAll(tasks);
                });

                thread.Name = "Thread" + i;
                thread.IsBackground = true;
                threadsPool[i] = thread;
                thread.Start();
                begin += step;
            }
            begin = beginCopy;
            for (int i = 0; i < threadsPool.Length; i++)
            {
                threadsPool[i].Join();
            }
            Assert.That(actualSum, Is.EqualTo(expectedSum));
        }
    }
}