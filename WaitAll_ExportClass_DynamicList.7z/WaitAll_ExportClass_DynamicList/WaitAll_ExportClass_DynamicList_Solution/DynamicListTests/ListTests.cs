using GenericDynamicList;

namespace DynamicListTests
{
    public class ListTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void AddTest()
        {
            DynamicList<int> dynamicList = new DynamicList<int>();

            dynamicList.Add(2);
            Assert.That(dynamicList.Count, Is.EqualTo(1));
            dynamicList.Add(3);
            Assert.That(dynamicList.Count, Is.EqualTo(2));

            Assert.That(dynamicList.Items[0], Is.EqualTo(2));
            Assert.That(dynamicList.Items[1], Is.EqualTo(3));

        }


        [Test]
        [TestCase(new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 })]

        public void RemoveAtTest(int[] initArray)
        {
            DynamicList<int> dynamicList = new DynamicList<int>(initArray);

            dynamicList.RemoveAt(2);

            Assert.That(dynamicList.Count, Is.EqualTo(10));
            Assert.That(dynamicList.Items, Is.EqualTo(new int[] { 0, 1, 3, 4, 5, 6, 7, 8, 9, 10 }));
            dynamicList.RemoveAt(dynamicList.Count - 1);
            Assert.That(dynamicList.Items, Is.EqualTo(new int[] { 0, 1, 3, 4, 5, 6, 7, 8, 9 }));
            dynamicList.RemoveAt(0);
            Assert.That(dynamicList.Items, Is.EqualTo(new int[] { 1, 3, 4, 5, 6, 7, 8, 9 }));


        }

        [Test]
        [TestCase(new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 })]

        public void RemoveTest(int[] initArray)
        {
            DynamicList<int> dynamicList = new DynamicList<int>(initArray);

            dynamicList.Add(2);
            dynamicList.Add(20);

            dynamicList.Remove(2);

            Assert.That(dynamicList.Count, Is.EqualTo(12));
            Assert.That(dynamicList.Items, Is.EqualTo(new int[] { 0, 1, 3, 4, 5, 6, 7, 8, 9, 10, 2, 20 }));
            dynamicList.Remove(2);
            Assert.That(dynamicList.Items, Is.EqualTo(new int[] { 0, 1, 3, 4, 5, 6, 7, 8, 9, 10, 20 }));
        }

        [Test]
        [TestCase(new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 })]

        public void ClearTest(int[] initArray)
        {
            DynamicList<int> dynamicList = new DynamicList<int>(initArray);

            dynamicList.Clear();
            Assert.That(dynamicList.Count, Is.EqualTo(0));
            Assert.That(dynamicList.Items, Is.EqualTo(new int[] { }));

            dynamicList.Add(1);
            Assert.That(dynamicList.Count, Is.EqualTo(1));
            Assert.That(dynamicList.Items[0], Is.EqualTo(1));
        }

        [Test]
        public void ExtendingTest()
        {
            DynamicList<int> dynamicList = new DynamicList<int>();

            dynamicList = new DynamicList<int>(4);
            for (int i = 0; i < 400; i++)
            {
                dynamicList.Add(i);
            }

            Assert.That(dynamicList.Count, Is.EqualTo(400));
            Assert.That(dynamicList.Items.Length, Is.EqualTo(400));
        }

        [Test]
        public void EnumeratorTest()
        {
            DynamicList<int> dynamicList = new DynamicList<int>();


            for (int i = 0; i < 110; i++)
            {
                dynamicList.Add(i);
            }

            int index = 0;
            using (var enumerator = dynamicList.GetEnumerator())
            {
                while (enumerator.MoveNext())
                {
                    int val = enumerator.Current;
                    Assert.That(val, Is.EqualTo(index++));
                }
            }
            Assert.That(index, Is.EqualTo(110));

        }
    }
}