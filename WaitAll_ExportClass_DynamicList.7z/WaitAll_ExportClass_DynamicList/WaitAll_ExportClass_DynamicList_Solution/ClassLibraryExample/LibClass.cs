﻿using ExportClassAttribute;

namespace ClassLibraryExample
{
    public class Test : System.Attribute
    {
        public Test()
        {

        }
    }

    public class CustomizedAttribute : System.Attribute
    {
        public CustomizedAttribute()
        {

        }
    }

    [ExportClass]
    [CustomizedAttribute]
    public class Demo1WithAttribute
    {
        public int Test1;
        public string Test2 = "";
    }

    [CustomizedAttribute]
    [ExportClass]
    [Test]

    public class Demo2WithAttribute
    {
        public int Test1;
        public string Test2 = "";
    }

    public class Demo3WithoutAttribute
    {
        public int Test1;
        public string Test2 = "";
    }

    [ExportClass]
    [Test]
    public class Demo4WithFewAttributes
    {
        public int Test1;
        public string Test2 = "";
    }

    [Test]
    public class Demo5WithAnotherAttribute
    {
        public int Test1;
        public string Test2 = "";
    }

    public delegate void TestDelegate();

    public enum TestEnum
    {
        TEST_E,
        TEST_B
    }

    public interface TestInterface
    {
        void Test();
    }

    public struct TestStruct
    {
        public int Test;
    }

    [ExportClass]

    public class Developer
    {
        private int salary;

        public int Salary
        {
            get 
            {
                return this.salary;
            }
        }

        public Developer(int salary) 
        {
            this.salary = salary;
        }
        
    }

    [CustomizedAttribute]
    [Test]

    public class Designer : Developer
    {

        private DesignerSkills designerSkills;
        public DesignerType designerType;

        public enum DesignerSkills
        {
            HTML,
            CSS,
            Illustrator,
            InDesign
        }

        public enum DesignerType
        {
            Game,
            WEB,
            Graphic
        }

        public Designer(int salary, DesignerSkills designerSkills, DesignerType designerType) : base(salary)
        {
            this.designerSkills = designerSkills;
            this.designerType = designerType;
        }

        
        public DesignerSkills Skills
        {
            get 
            {
                return designerSkills;
            }
        }

        public DesignerType GetDesignerType()
        {
            return designerType;
        }
    }
}
